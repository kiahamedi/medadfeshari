    $(document).ready(function() {
     
      $("#owl-example").owlCarousel({
      	'items' : 1,
      	'itemsDesktop':1,
      	'itemsDesktopSmall':1,
      	'itemsTablet':1,
      	'itemsMobile':1,
      	'navigation':true,
      	'pagination':true,
      	'navigationText':["داستان قبلی","داستان بعدی"]
      });
	      
    });